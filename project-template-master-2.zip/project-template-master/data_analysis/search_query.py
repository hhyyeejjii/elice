import pandas as pd

data = pd.read_csv('data/mbti_movie.csv', encoding='utf-8')