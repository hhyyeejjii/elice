# Feature Request

- Part
  - [ ] Front-End
  - [ ] Back-End
  - [ ] 데이터 분석
  <br>
- 기능 상세 설명
  - 기능에서 어떤 부분이 구현되어야 하는 지 설명해주세요.
  - Ex) A기능에서 B데이터를 원형 그래프로 구현
  <br>
- Deadline
  - 마감 기한을 설정해주세요
  - Ex) 2021-11-12
